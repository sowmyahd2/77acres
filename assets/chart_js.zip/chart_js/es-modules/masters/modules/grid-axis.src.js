/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * GridAxis
 *
 * (c) 2016-2019 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/GridAxis.js';
