/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 * Timeline series
 *
 * (c) 2010-2019 Highsoft AS
 * Author: Daniel Studencki
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/timeline.src.js';
